package com.example.demo.exception;

// 오류 메시지 : 글을 찾을 수 없음
public class BoardNotFoundException extends RuntimeException {
	
}
